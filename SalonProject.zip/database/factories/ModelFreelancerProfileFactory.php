<?php

use Faker\Generator as Faker;

$factory->define(App\Model\FreelancerProfile::class, function (Faker $faker) {
    return [
        //
    ];
});
