<?php

use Faker\Generator as Faker;

$factory->define(App\Model\Qualitification::class, function (Faker $faker) {
    return [
        //
    ];
});
