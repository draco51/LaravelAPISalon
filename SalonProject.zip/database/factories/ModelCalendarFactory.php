<?php

use Faker\Generator as Faker;

$factory->define(App\Model\Calendar::class, function (Faker $faker) {
    return [
        //
    ];
});
